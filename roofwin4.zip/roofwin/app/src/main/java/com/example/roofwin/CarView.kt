package com.example.roofwin

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import org.json.JSONArray
import org.json.JSONObject

class CarView(ctx: Context) : View(ctx) {
    class Zone(val key: String, val label: String, val area: Int, val poly: Path, val pts: List<PointF>) { var pct = 0 }

    private val g = JSONObject(ctx.resources.openRawResource(R.raw.geo).bufferedReader().readText())
    private val meta = g.getJSONObject("meta")
    private val gw = meta.getDouble("W").toFloat()
    private val gh = meta.getDouble("H").toFloat()
    private fun pts(k: String): List<PointF> { val a = g.getJSONArray(k); return List(a.length()) { val p = a.getJSONArray(it); PointF(p.getDouble(0).toFloat(), p.getDouble(1).toFloat()) } }
    private fun path(l: List<PointF>) = Path().apply { l.forEachIndexed { i, p -> if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y) }; close() }

    private val body = listOf("body_top", "body_left", "body_right").map { path(pts(it)) }
    private val wheels: List<FloatArray> = listOf("wheels_left", "wheels_right").flatMap { k ->
        val a = g.getJSONArray(k); List(a.length()) { val p = a.getJSONArray(it); floatArrayOf(p.getDouble(0).toFloat(), p.getDouble(1).toFloat(), p.getDouble(2).toFloat()) } }
    val zones = listOf(
        zone("FL", "سائق", CarControl.DRIVER), zone("RL", "خلفي ي", CarControl.REAR_LEFT),
        zone("FR", "راكب", CarControl.FRONT_PASSENGER), zone("RR", "خلفي ر", CarControl.REAR_RIGHT),
        zone("SUNROOF", "السقف", CarControl.ROOF_GLASS))
    private fun zone(k: String, l: String, a: Int): Zone { val p = pts(k); return Zone(k, l, a, path(p), p) }

    var status = "المس نافذة: فتح/غلق • ضغط مطوّل = 50%"
    private val ui = Handler(Looper.getMainLooper())
    private var s = 1f; private var ox = 0f; private var oy = 0f
    private val top = 70f

    private val pBody = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2B3340.toInt() }
    private val pLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF6B778C.toInt(); strokeWidth = 2f }
    private val pGlass = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3B82C4.toInt() }
    private val pOpen = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF10151C.toInt() }
    private val pEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 3f }
    private val pTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 24f }
    private val pWheel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF111111.toInt() }

    override fun onMeasure(w: Int, h: Int) {
        val ww = MeasureSpec.getSize(w).let { if (it == 0) 360 else it }
        setMeasuredDimension(ww, (ww * gh / gw + top + 50).toInt())
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        s = minOf(w / gw, (h - top - 50) / gh); ox = (w - gw * s) / 2; oy = top
    }
    private fun toScreen(m: Matrix) = m.apply { setScale(s, s); postTranslate(ox, oy) }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xE60B0F14.toInt())
        pTxt.textSize = 26f; c.drawText(status, width / 2f, 40f, pTxt)
        val m = toScreen(Matrix())
        val tmp = Path()
        for (b in body) { b.transform(m, tmp); c.drawPath(tmp, pBody); c.drawPath(tmp, pLine) }
        for (w in wheels) c.drawCircle(ox + w[0] * s, oy + w[1] * s, w[2] * s, pWheel)
        for (z in zones) {
            z.poly.transform(m, tmp)
            c.drawPath(tmp, pGlass)
            if (z.pct > 0) {
                c.save(); c.clipPath(tmp)
                val b = RectF(); tmp.computeBounds(b, true)
                if (z.key == "SUNROOF") c.drawRect(b.left, b.top, b.right, b.top + b.height() * z.pct / 100f, pOpen)
                else c.drawRect(b.left, b.top, b.right, b.top + b.height() * z.pct / 100f, pOpen)
                c.restore()
            }
            c.drawPath(tmp, pEdge)
            val b = RectF(); tmp.computeBounds(b, true)
            pTxt.textSize = 20f
            c.drawText("${z.label} ${z.pct}%", b.centerX(), b.centerY() + 7f, pTxt)
        }
        pTxt.textSize = 20f
        c.drawText("مفتوح = أسود • اللمسة تبدّل • ضغط مطوّل 50%", width / 2f, height - 14f, pTxt)
    }

    private fun hit(x: Float, y: Float): Zone? {
        val gx = (x - ox) / s; val gy = (y - oy) / s
        return zones.firstOrNull { z ->
            var inside = false; var j = z.pts.size - 1
            for (i in z.pts.indices) {
                val a = z.pts[i]; val b = z.pts[j]
                if ((a.y > gy) != (b.y > gy) && gx < (b.x - a.x) * (gy - a.y) / (b.y - a.y) + a.x) inside = !inside
                j = i
            }
            inside
        }
    }

    private var down: Zone? = null; private var longFired = false
    private val lp = Runnable { down?.let { longFired = true; send(it, 50) } }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = hit(e.x, e.y); longFired = false; if (down != null) ui.postDelayed(lp, 600); return true }
            MotionEvent.ACTION_UP -> {
                ui.removeCallbacks(lp)
                val z = down; if (z != null && !longFired && hit(e.x, e.y) === z) send(z, if (z.pct > 0) 0 else 100)
                down = null
            }
            MotionEvent.ACTION_CANCEL -> { ui.removeCallbacks(lp); down = null }
        }
        return true
    }

    private fun send(z: Zone, pct: Int) {
        CarControl.set(context, z.area, pct).onSuccess {
            z.pct = pct; status = "${z.label}: ${if (pct == 0) "مغلق" else if (pct == 100) "مفتوح" else "$pct%"}"
        }.onFailure { status = "خطأ: " + Panel.err(it) }
        invalidate()
    }

    fun refresh() { zones.forEach { z -> CarControl.get(context, z.area)?.let { z.pct = it } }; invalidate() }
}
