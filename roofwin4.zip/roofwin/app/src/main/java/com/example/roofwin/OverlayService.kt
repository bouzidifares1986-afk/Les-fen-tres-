package com.example.roofwin

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.*

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var big = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "roofwin"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "RoofWin", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch)
            .setContentTitle("RoofWin").setSmallIcon(android.R.drawable.ic_menu_manage).build())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val car = CarView(this)

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#FF1F2937")); gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "⠿ RoofWin — اسحب للتحريك"; setTextColor(Color.WHITE); setPadding(12, 8, 12, 8) }
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(Button(this).apply { text = "⤢"; setOnClickListener {
            big = !big; lp!!.width = ((if (big) 460 else 320) * d).toInt(); wm!!.updateViewLayout(root, lp) } })
        bar.addView(Button(this).apply { text = "✕"; setOnClickListener { stopSelf() } })

        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(bar); addView(car) }

        lp = WindowManager.LayoutParams((320 * d).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 80 }

        var sx = 0f; var sy = 0f; var ix = 0; var iy = 0
        title.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ix = lp!!.x; iy = lp!!.y }
                MotionEvent.ACTION_MOVE -> { lp!!.x = ix + (e.rawX - sx).toInt(); lp!!.y = iy + (e.rawY - sy).toInt(); wm!!.updateViewLayout(root, lp) }
            }
            true
        }
        wm!!.addView(root, lp)
        car.post { car.refresh() }
    }

    override fun onDestroy() { root?.let { wm?.removeView(it) }; super.onDestroy() }
}
