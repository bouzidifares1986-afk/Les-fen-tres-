# Roof & Windows 3D
- Android Studio: Open ← هذا المجلد ← Build > Build APK(s)   |   أو ارفعه إلى GitHub وشغّل workflow "build-apk".
- الواجهة: app/src/main/assets (index.html + bundle.js + car.glb). الكود المصدري للعارض: viewer-src/main.js
- ربط السيارة: app/src/main/java/com/example/roofwin/CarController.kt  (الدالة sendToCar)
