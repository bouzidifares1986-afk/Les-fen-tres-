import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { MeshoptDecoder } from 'three/examples/jsm/libs/meshopt_decoder.module.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

const $ = (s) => document.querySelector(s);
const canvas = $('#c');
const stage = $('#stage');
const statusEl = $('#status');
const loadEl = $('#loading');

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
renderer.localClippingEnabled = true;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;

const scene = new THREE.Scene();
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
const sun = new THREE.DirectionalLight(0xffffff, 1.2);
sun.position.set(3, 6, 4);
scene.add(sun);

const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
const controls = new OrbitControls(camera, canvas);
controls.target.set(0, 0.75, 0.1);
controls.enablePan = false;
controls.minDistance = 3.2;
controls.maxDistance = 11;
controls.maxPolarAngle = Math.PI * 0.49;
controls.addEventListener('change', requestRender);

const VIEWS = {
  three: { p: [4.1, 2.6, 4.6], t: [0, 0.75, 0.1] },
  side:  { p: [7.2, 1.2, 0.1], t: [0, 0.8, 0.1] },
  top:   { p: [0.01, 8.2, 0.1], t: [0, 0.8, 0.1] },
};
function setView(name) {
  const v = VIEWS[name];
  camera.position.set(...v.p);
  controls.target.set(...v.t);
  controls.update();
  requestRender();
}

let needsRender = true;
function requestRender() { needsRender = true; }

function resize() {
  const w = stage.clientWidth, h = stage.clientHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w / Math.max(1, h);
  camera.updateProjectionMatrix();
  requestRender();
}
new ResizeObserver(resize).observe(stage);

// ---------- Parts ----------
const PARTS = [
  { id: 'FL',  type: 'window', node: 'Coolray_Door_FL_Body',       label: 'أمامية يسار', short: 'ي‑أ', belt: 1.03,  travel: 0.47 },
  { id: 'FR',  type: 'window', node: 'Coolray_Door_FR_Body',       label: 'أمامية يمين', short: 'م‑أ', belt: 1.03,  travel: 0.47 },
  { id: 'RL',  type: 'window', node: 'Coolray_Door_RL_Body',       label: 'خلفية يسار',  short: 'ي‑خ', belt: 1.04,  travel: 0.47 },
  { id: 'RR',  type: 'window', node: 'Coolray_Door_RL_Body001',    label: 'خلفية يمين',  short: 'م‑خ', belt: 1.04,  travel: 0.47 },
  { id: 'ROOF', type: 'roof',  node: 'Coolray_SunRoof_Front',      label: 'فتحة السقف',  short: 'سقف', travel: 0.58, lift: 0.03 },
];
const byId = {};
const proxies = [];
const occluders = [];
let car = null;

const ZONE = { window: 0x2ea8ff, roof: 0xffa726 };
const tmpV = new THREE.Vector3();

function localDelta(obj, worldDelta) {
  // convert a world-space displacement into obj.parent local space
  obj.parent.updateWorldMatrix(true, false);
  const inv = new THREE.Matrix4().copy(obj.parent.matrixWorld).invert();
  const a = new THREE.Vector3().setFromMatrixPosition(obj.parent.matrixWorld);
  const b = a.clone().add(worldDelta);
  return b.applyMatrix4(inv).sub(a.applyMatrix4(inv));
}

function setupPart(p) {
  const node = car.getObjectByName(p.node);
  if (!node) { console.warn('missing node', p.node); return; }
  let mover, geoMesh;
  if (p.type === 'window') {
    node.traverse((o) => { if (o.isMesh && o.material && o.material.name === 'Coolray_Glass') geoMesh = o; });
    mover = geoMesh;
    mover.material = mover.material.clone();
    p.clip = new THREE.Plane(new THREE.Vector3(0, 1, 0), -p.belt);
    mover.material.clippingPlanes = [p.clip];
    p.worldDelta = new THREE.Vector3(0, -p.travel, 0);
  } else {
    node.traverse((o) => { if (o.isMesh && o.material && /Glass/.test(o.material.name)) geoMesh = o; });
    mover = node;
    p.worldDelta = new THREE.Vector3(0, p.lift, -p.travel);
  }
  p.mover = mover;
  p.glass = geoMesh;
  p.base = mover.position.clone();
  p.local = localDelta(mover, p.worldDelta);
  p.amount = 0; p.target = 0;

  // hit zone: static invisible copy of the closed glass, tinted overlay
  geoMesh.updateWorldMatrix(true, false);
  const mat = new THREE.MeshBasicMaterial({
    color: ZONE[p.type], transparent: true, opacity: 0.22, depthWrite: false,
    polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, side: THREE.DoubleSide,
  });
  const zone = new THREE.Mesh(geoMesh.geometry, mat);
  zone.matrixAutoUpdate = false;
  zone.matrix.copy(geoMesh.matrixWorld);
  zone.matrixWorld.copy(geoMesh.matrixWorld);
  zone.userData.part = p;
  zone.renderOrder = 5;
  scene.add(zone);
  p.zone = zone;
  proxies.push(zone);
  const box = new THREE.Box3().setFromObject(zone);
  p.anchor = box.getCenter(new THREE.Vector3());
  byId[p.id] = p;
}

function applyAmount(p) {
  p.mover.position.copy(p.base);
  let a = p.amount;
  if (p.type === 'roof') {
    const lift = Math.min(1, a * 6);
    const wd = new THREE.Vector3(0, p.lift * lift, -p.travel * a);
    p.mover.position.add(localDelta(p.mover, wd));
  } else {
    p.mover.position.addScaledVector(p.local, a);
  }
  p.mover.updateMatrixWorld(true);
  requestRender();
}

// ---------- Labels ----------
const labelsEl = $('#labels');
function makeLabels() {
  for (const p of PARTS) {
    if (!p.zone) continue;
    const el = document.createElement('div');
    el.className = 'tag ' + p.type;
    el.innerHTML = '<b>' + p.short + '</b><i></i>';
    labelsEl.appendChild(el);
    p.tagEl = el;
  }
}
function updateLabels() {
  const w = stage.clientWidth, h = stage.clientHeight;
  for (const p of PARTS) {
    if (!p.tagEl) continue;
    tmpV.copy(p.anchor).project(camera);
    const n = p.type === 'roof' ? [0, 1, 0] : [Math.sign(p.anchor.x), 0, 0];
    const facing = (camera.position.x - p.anchor.x) * n[0] + (camera.position.y - p.anchor.y) * n[1] + (camera.position.z - p.anchor.z) * n[2] > 0;
    p.zone.visible = facing && zonesOn;
    const vis = tmpV.z < 1 && facing;
    p.tagEl.style.display = vis ? '' : 'none';
    p.tagEl.style.transform = 'translate(' + ((tmpV.x * 0.5 + 0.5) * w) + 'px,' + ((-tmpV.y * 0.5 + 0.5) * h) + 'px) translate(-50%,-50%)';
    p.tagEl.querySelector('i').textContent = Math.round(p.amount * 100) + '%';
    p.tagEl.classList.toggle('on', p.amount > 0.02);
  }
}

// ---------- Interaction ----------
const ray = new THREE.Raycaster();
const ndc = new THREE.Vector2();
function setNdc(e) {
  const r = canvas.getBoundingClientRect();
  ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  ray.setFromCamera(ndc, camera);
}
function pick(e) {
  setNdc(e);
  const hits = ray.intersectObjects(proxies, false);
  if (!hits.length) return null;
  const h = hits[0];
  // occlusion by the car body
  const o = new THREE.Raycaster(ray.ray.origin, ray.ray.direction, 0, Math.max(0, h.distance - 0.02));
  if (occluders.length && o.intersectObjects(occluders, false).length) return null;
  return h.object.userData.part;
}
function screenVec(p) {
  const w = stage.clientWidth, h = stage.clientHeight;
  const a = p.anchor.clone().project(camera);
  const b = p.anchor.clone().add(p.worldDelta).project(camera);
  let vx = (b.x - a.x) * 0.5 * w, vy = -(b.y - a.y) * 0.5 * h;
  let L = Math.hypot(vx, vy);
  const MIN = 90;
  if (L < 1e-3) { vx = 0; vy = MIN; L = MIN; }
  if (L < MIN) { vx *= MIN / L; vy *= MIN / L; L = MIN; }
  return { vx, vy, L2: L * L };
}

let drag = null;
let zonesOn = true;
canvas.addEventListener('pointerdown', (e) => {
  const p = pick(e);
  if (!p) return;
  controls.enabled = false;
  canvas.setPointerCapture(e.pointerId);
  const sv = screenVec(p);
  drag = { p, id: e.pointerId, x0: e.clientX, y0: e.clientY, a0: p.amount, sv, moved: false };
  p.target = p.amount;
  p.zone.material.opacity = 0.5;
  setStatus(p.label + ' — اسحب للفتح أو الغلق، أو المس مرة واحدة');
  requestRender();
  e.preventDefault();
}, { passive: false });
canvas.addEventListener('pointermove', (e) => {
  if (!drag || e.pointerId !== drag.id) return;
  const dx = e.clientX - drag.x0, dy = e.clientY - drag.y0;
  if (!drag.moved && Math.hypot(dx, dy) > 8) drag.moved = true;
  if (drag.moved) {
    const k = (dx * drag.sv.vx + dy * drag.sv.vy) / drag.sv.L2;
    drag.p.amount = drag.p.target = Math.min(1, Math.max(0, drag.a0 + k));
    applyAmount(drag.p);
    setStatus(drag.p.label + ' : ' + Math.round(drag.p.amount * 100) + '%');
  }
});
function endDrag(e) {
  if (!drag || (e && e.pointerId !== drag.id)) return;
  const p = drag.p;
  if (!drag.moved) p.target = p.amount > 0.5 ? 0 : 1; // tap = toggle
  p.zone.material.opacity = 0.22;
  send(p.id, p.target);
  setStatus(p.label + (p.target >= 0.99 ? ' — مفتوحة' : p.target <= 0.01 ? ' — مغلقة' : ' — ' + Math.round(p.target * 100) + '%'));
  drag = null;
  controls.enabled = true;
  requestRender();
}
canvas.addEventListener('pointerup', endDrag);
canvas.addEventListener('pointercancel', endDrag);

function setStatus(t) { statusEl.textContent = t; }

// ---------- Commands to the car ----------
function send(id, frac) {
  const pct = Math.round(frac * 100);
  try {
    if (window.Android && window.Android.onPart) window.Android.onPart(id, pct);
  } catch (err) { console.warn(err); }
}
// the native side can push the real state: setPart('FL', 40)
window.setPart = (id, pct) => {
  const p = byId[id]; if (!p) return;
  p.target = Math.min(1, Math.max(0, pct / 100));
  requestRender();
};
function setAll(v) {
  for (const p of PARTS) if (p.zone) { p.target = v; send(p.id, v); }
  setStatus(v ? 'فتح الكل' : 'غلق الكل');
  requestRender();
}
$('#openAll').onclick = () => setAll(1);
$('#closeAll').onclick = () => setAll(0);
document.querySelectorAll('[data-view]').forEach((b) => (b.onclick = () => setView(b.dataset.view)));
$('#zones').onclick = (e) => {
  const on = !e.currentTarget.classList.toggle('off');
  zonesOn = on;
  labelsEl.style.display = on ? '' : 'none';
  requestRender();
};

// ---------- Loop ----------
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  for (const p of PARTS) {
    if (!p.mover || drag?.p === p) continue;
    if (Math.abs(p.amount - p.target) > 1e-3) {
      const step = dt / 0.45;
      p.amount += Math.sign(p.target - p.amount) * Math.min(Math.abs(p.target - p.amount), step);
      applyAmount(p);
    }
  }
  if (needsRender) { needsRender = false; renderer.render(scene, camera); updateLabels(); }
}

// ---------- Load ----------
const loader = new GLTFLoader();
loader.setMeshoptDecoder(MeshoptDecoder);
const url = new URLSearchParams(location.search).get('glb') || 'car.glb';
loader.load(url, (gltf) => {
  car = gltf.scene;
  scene.add(car);
  car.updateMatrixWorld(true);
  for (const p of PARTS) setupPart(p);
  // body panels that can hide a window from the opposite side
  car.traverse((o) => {
    if (o.isMesh && /^Coolray_(EXT_CarPaint|Door_\w+_CarPaint)/.test(o.name) && !(o.material && /Glass/.test(o.material.name))) occluders.push(o);
  });
  makeLabels();
  loadEl.style.display = 'none';
  setView('three');
  resize();
  setStatus('المس نافذة أو السقف في الرسمة');
  window.__ready = true;
}, (ev) => {
  if (ev.total) loadEl.textContent = 'تحميل النموذج… ' + Math.round((ev.loaded / ev.total) * 100) + '%';
  else loadEl.textContent = 'تحميل النموذج… ' + (ev.loaded / 1048576).toFixed(1) + ' MB';
}, (err) => { loadEl.textContent = 'تعذّر تحميل النموذج: ' + (err && err.message || err); console.error(err); });

requestAnimationFrame(frame);
window.__dbg = { PARTS, camera, controls, setView, scene, renderer };
