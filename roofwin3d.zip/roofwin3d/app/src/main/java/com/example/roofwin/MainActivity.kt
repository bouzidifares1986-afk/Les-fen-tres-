package com.example.roofwin

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad); gravity = Gravity.CENTER_HORIZONTAL }
        col.addView(TextView(this).apply {
            text = "التحكم بالنوافذ والسقف — نموذج GLB ثلاثي الأبعاد\n\nالمس النافذة أو السقف في الرسمة ثم اسحب لفتحها/غلقها، أو المسها مرة واحدة للتبديل."
            textSize = 16f
        })
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { col.addView(it) }
        btn("1) السماح بالعرض فوق التطبيقات") {
            if (Settings.canDrawOverlays(this)) Toast.makeText(this, "الإذن ممنوح", Toast.LENGTH_SHORT).show()
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2) تشغيل النافذة العائمة") {
            if (!Settings.canDrawOverlays(this)) Toast.makeText(this, "امنح الإذن أولاً (الزر 1)", Toast.LENGTH_LONG).show()
            else startService(Intent(this, FloatingService::class.java))
        }
        btn("إيقاف النافذة العائمة") { stopService(Intent(this, FloatingService::class.java)) }
        col.addView(TextView(this).apply {
            text = "\nإن لم تظهر شاشة الإذن على الطابلت:\nadb shell appops set $packageName SYSTEM_ALERT_WINDOW allow"
            textSize = 13f
        })
        setContentView(col)
    }
}
