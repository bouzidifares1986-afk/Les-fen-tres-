package com.example.roofwin

import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast

/**
 * نقطة الإرسال الوحيدة نحو السيارة.
 * id  : FL (أمامية يسار) / FR (أمامية يمين) / RL (خلفية يسار) / RR (خلفية يمين) / ROOF (فتحة السقف)
 * percent : 0 = مغلق تماماً ... 100 = مفتوح تماماً
 *
 * ملاحظة: لم يُربط بعد بأمر حقيقي في السيارة. استبدل جسم sendToCar بالاستدعاء الفعلي.
 */
object CarController {
    const val ACTION = "com.example.roofwin.ACTION_PART"

    fun setPart(ctx: Context, id: String, percent: Int) {
        Log.i("RoofWin", "part=$id percent=$percent")
        sendToCar(ctx, id, percent)
    }

    private fun sendToCar(ctx: Context, id: String, percent: Int) {
        // مؤقتاً: بثّ Intent داخلي + رسالة صغيرة لتأكيد وصول الأمر من الرسمة
        ctx.sendBroadcast(Intent(ACTION).setPackage(ctx.packageName).putExtra("id", id).putExtra("percent", percent))
        Toast.makeText(ctx, "$id → $percent%", Toast.LENGTH_SHORT).show()
    }
}
