package com.example.roofwin

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import java.io.ByteArrayInputStream
import java.io.IOException

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private var web: WebView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val sizes = arrayOf(560 to 400, 820 to 540, 1100 to 700) // dp
    private var sizeIdx = 1
    private val HOST = "appassets.local"
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        startForeground(7, notification())
        if (root == null) show()
        return START_STICKY
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("roofwin", "Roof & Windows", NotificationManager.IMPORTANCE_MIN))
        return Notification.Builder(this, "roofwin").setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("التحكم بالنوافذ والسقف").build()
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("roofwin", MODE_PRIVATE)
        sizeIdx = prefs.getInt("size", 1)
        lp = WindowManager.LayoutParams(
            dp(sizes[sizeIdx].first), dp(sizes[sizeIdx].second) + dp(40),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = prefs.getInt("x", dp(60)); y = prefs.getInt("y", dp(60)) }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#10161d")) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#0b1015")); gravity = Gravity.CENTER_VERTICAL
        }
        fun chip(t: String, click: () -> Unit) = TextView(this).apply {
            text = t; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(16), 0, dp(16), 0); setOnClickListener { click() }
        }
        val title = TextView(this).apply {
            text = "⠿  اسحب من هنا لتحريك النافذة"; textSize = 14f; setTextColor(Color.parseColor("#9fb6cb")); setPadding(dp(12), 0, 0, 0)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(40), 1f))
        header.addView(chip("▭") { sizeIdx = (sizeIdx + 1) % sizes.size; applySize(); prefs.edit().putInt("size", sizeIdx).apply() }, LinearLayout.LayoutParams(-2, dp(40)))
        header.addView(chip("✕") { stopSelf() }, LinearLayout.LayoutParams(-2, dp(40)))

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        title.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); wm.updateViewLayout(col, lp) }
                MotionEvent.ACTION_UP -> prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
            }
            true
        }

        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.allowFileAccess = false
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        w.addJavascriptInterface(object {
            @JavascriptInterface fun onPart(id: String, percent: Int) { CarController.setPart(applicationContext, id, percent) }
        }, "Android")
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (r.url.host != HOST) return null
                var path = (r.url.path ?: "").trimStart('/')
                if (path.isEmpty()) path = "index.html"
                val mime = when {
                    path.endsWith(".html") -> "text/html"; path.endsWith(".js") -> "application/javascript"
                    path.endsWith(".glb") -> "model/gltf-binary"; else -> "application/octet-stream"
                }
                return try {
                    WebResourceResponse(mime, "utf-8", 200, "OK",
                        mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "max-age=86400"), this@FloatingService.assets.open(path))
                } catch (e: IOException) {
                    WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
            }
        }
        col.addView(header, LinearLayout.LayoutParams(-1, dp(40)))
        col.addView(w, LinearLayout.LayoutParams(-1, 0, 1f))
        root = col; web = w
        wm.addView(col, lp)
        w.loadUrl("https://$HOST/index.html")
    }

    private fun applySize() {
        lp.width = dp(sizes[sizeIdx].first); lp.height = dp(sizes[sizeIdx].second) + dp(40)
        root?.let { wm.updateViewLayout(it, lp) }
    }

    override fun onDestroy() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        web?.destroy(); web = null; root = null
        super.onDestroy()
    }
}
