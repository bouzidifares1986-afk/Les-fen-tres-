package com.example.roofwin

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.*

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "roofwin"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "RoofWin", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch)
            .setContentTitle("RoofWin").setSmallIcon(android.R.drawable.ic_menu_manage).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#E6202020"))
            setPadding(24, 24, 24, 24)
        }
        row("السائق", CarControl.DRIVER)
        row("الراكب", CarControl.FRONT_PASSENGER)
        row("خلفي يسار", CarControl.REAR_LEFT)
        row("خلفي يمين", CarControl.REAR_RIGHT)
        row("السقف", CarControl.ROOF_GLASS)
        row("الستارة", CarControl.SUNSHADE)
        root!!.addView(Button(this).apply { text = "إغلاق الأداة"; setOnClickListener { stopSelf() } })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,           // 2038
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm!!.addView(root, lp)
    }

    private fun row(title: String, area: Int) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        r.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); minWidth = 220 })
        // 0 = مغلق ، 100 = مفتوح (تحقق منها على سيارتك أولاً)
        fun btn(label: String, v: Int) = Button(this).apply {
            text = label
            setOnClickListener {
                CarControl.set(this@OverlayService, area, v).onFailure {
                    Toast.makeText(context, "فشل: ${it.cause?.message ?: it.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        r.addView(btn("إغلاق", 0)); r.addView(btn("50%", 50)); r.addView(btn("فتح", 100))
        root!!.addView(r)
    }

    override fun onDestroy() { root?.let { wm?.removeView(it) }; super.onDestroy() }
}
