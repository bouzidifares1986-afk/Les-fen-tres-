package com.example.roofwin

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.*

object Panel {
    private val items = listOf(
        "السائق" to CarControl.DRIVER,
        "الراكب" to CarControl.FRONT_PASSENGER,
        "خلفي يسار" to CarControl.REAR_LEFT,
        "خلفي يمين" to CarControl.REAR_RIGHT,
        "السقف" to CarControl.ROOF_GLASS,
        "الستارة" to CarControl.SUNSHADE,
    )

    /** يبني الأزرار؛ onMsg يستقبل نتيجة كل أمر (نجاح/خطأ). */
    fun build(ctx: Context, dark: Boolean, onMsg: (String) -> Unit): LinearLayout {
        val fg = if (dark) Color.WHITE else Color.BLACK
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        for ((title, area) in items) {
            val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            r.addView(TextView(ctx).apply { text = title; setTextColor(fg); minWidth = 220 })
            fun btn(label: String, v: Int) = Button(ctx).apply {
                text = label
                setOnClickListener {
                    val res = CarControl.set(ctx, area, v)
                    onMsg(
                        res.fold(
                            { "$title ← $v : تم الإرسال" },
                            { "$title ← $v : فشل: ${err(it)}" }
                        )
                    )
                }
            }
            r.addView(btn("إغلاق", 0)); r.addView(btn("50%", 50)); r.addView(btn("فتح", 100))
            root.addView(r)
        }
        return root
    }

    fun err(t: Throwable): String {
        var e: Throwable = t
        while (e.cause != null && e.cause !== e) e = e.cause!!
        return "${e.javaClass.simpleName}: ${e.message}"
    }
}
