package com.example.roofwin

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.*

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "roofwin"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "RoofWin", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch)
            .setContentTitle("RoofWin").setSmallIcon(android.R.drawable.ic_menu_manage).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#E6202020"))
            setPadding(24, 24, 24, 24)
        }
        val msg = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f }
        root!!.addView(Panel.build(this, true) { msg.text = it })
        root!!.addView(msg)
        root!!.addView(Button(this).apply { text = "إغلاق الأداة"; setOnClickListener { stopSelf() } })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm!!.addView(root, lp)
    }

    override fun onDestroy() { root?.let { wm?.removeView(it) }; super.onDestroy() }
}
