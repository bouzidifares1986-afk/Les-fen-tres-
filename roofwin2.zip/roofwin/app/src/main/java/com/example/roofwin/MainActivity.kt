package com.example.roofwin

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        val status = TextView(this).apply { textSize = 14f }

        col.addView(TextView(this).apply { text = "RoofWin — اختبار النوافذ والسقف"; textSize = 18f })

        col.addView(Button(this).apply {
            text = "1) السماح بالعرض فوق التطبيقات"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } catch (e: Exception) { status.text = "تعذر فتح الإعدادات: ${Panel.err(e)}" }
            }
        })
        col.addView(Button(this).apply {
            text = "2) تشغيل الأداة العائمة"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) status.text = "صلاحية العرض فوق التطبيقات غير ممنوحة"
                else try { startForegroundService(Intent(this@MainActivity, OverlayService::class.java)); status.text = "تم التشغيل" }
                catch (e: Exception) { status.text = "فشل: ${Panel.err(e)}" }
            }
        })
        col.addView(Button(this).apply {
            text = "قراءة موضع السقف (اختبار الاتصال)"
            setOnClickListener {
                val v = CarControl.get(this@MainActivity, CarControl.ROOF_GLASS)
                status.text = if (v == null) "لا توجد قراءة (الصلاحية أو الخاصية غير متاحة)" else "موضع السقف: $v"
            }
        })
        col.addView(TextView(this).apply { text = "\nأزرار مباشرة:"; textSize = 14f })
        col.addView(Panel.build(this, false) { status.text = it })
        col.addView(status)

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
