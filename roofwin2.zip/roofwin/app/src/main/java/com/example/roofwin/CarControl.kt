package com.example.roofwin

import android.content.Context

/** كتابة خاصية VHAL (0x13400BC0) بالـ reflection لأن android.car ليس في SDK العام. */
object CarControl {
    const val PROP = 0x13400BC0          // 322964416
    const val DRIVER = 16
    const val FRONT_PASSENGER = 64
    const val REAR_LEFT = 256
    const val REAR_RIGHT = 1024
    const val ROOF_GLASS = 65536
    const val SUNSHADE = 131072

    private var mgr: Any? = null

    private fun manager(ctx: Context): Any {
        mgr?.let { return it }
        val car = Class.forName("android.car.Car")
            .getMethod("createCar", Context::class.java).invoke(null, ctx)!!
        val m = car.javaClass.getMethod("getCarManager", String::class.java).invoke(car, "property")!!
        mgr = m; return m
    }

    /** percent: 0..100 */
    fun set(ctx: Context, area: Int, percent: Int): Result<Unit> = runCatching {
        val m = manager(ctx)
        m.javaClass.getMethod("setIntProperty", Int::class.java, Int::class.java, Int::class.java)
            .invoke(m, PROP, area, percent.coerceIn(0, 100))
        Unit
    }

    fun get(ctx: Context, area: Int): Int? = runCatching {
        val m = manager(ctx)
        val v = m.javaClass.getMethod("getProperty", Int::class.java, Int::class.java).invoke(m, PROP, area)
        v?.javaClass?.getMethod("getValue")?.invoke(v) as? Int
    }.getOrNull()
}
