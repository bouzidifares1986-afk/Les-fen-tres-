(function(){
'use strict';
var $=function(s){return document.querySelector(s)};
var N=window.AndroidNative||null;
function say(t){var e=$('#status');if(e)e.textContent=t}
window.addEventListener('error',function(e){say('JS: '+e.message)});
window.__native=function(m){say(String(m))};

/* ---------------- بيانات الواجهة ---------------- */
var LIGHTS=[
 {id:'pos',  t:'أضواء صغيرة', c:''},
 {id:'low',  t:'ضوء قريب',    c:''},
 {id:'high', t:'ضوء بعيد',    c:''},
 {id:'drl',  t:'نهاري DRL',   c:''},
 {id:'ffog', t:'ضباب أمامي',  c:'amber'},
 {id:'rfog', t:'ضباب خلفي',   c:'red'},
 {id:'tl',   t:'غمازة يسار',  c:'amber'},
 {id:'tr',   t:'غمازة يمين',  c:'amber'},
 {id:'haz',  t:'طوارئ',       c:'red', send:true},
 {id:'brake',t:'فرامل',       c:'red'},
 {id:'rev',  t:'رجوع',        c:''},
 {id:'cabin',t:'إنارة السقف', c:''}
];
var DOORS=[
 {id:'FL',t:'باب أمامي يسار'},{id:'FR',t:'باب أمامي يمين'},
 {id:'RL',t:'باب خلفي يسار'},{id:'RR',t:'باب خلفي يمين'},
 {id:'TRUNK',t:'الصندوق'},{id:'HOOD',t:'الكاپوت (حالة فقط)'}
];
var lightOn={},doorAmt={},doorTgt={};
LIGHTS.forEach(function(l){lightOn[l.id]=false});
DOORS.forEach(function(d){doorAmt[d.id]=0;doorTgt[d.id]=0});

/* ---------------- اللوحة السفلية ---------------- */
var panel=$('#panel'),tab='win';
function chip(txt,sub,cls,on,fn){
  var e=document.createElement('div');e.className='chip '+(cls||'')+(on?' on':'');
  e.innerHTML=txt+(sub?'<small>'+sub+'</small>':'');
  e.addEventListener('click',fn);return e;
}
function render(){
  panel.innerHTML='';
  if(tab==='win'){
    var P=(window.__dbg&&window.__dbg.PARTS)||[];
    P.forEach(function(p){
      panel.appendChild(chip(p.label,Math.round((p.amount||0)*100)+'% · اضغط للتبديل','send',(p.amount||0)>.02,function(){
        p.target=(p.amount>.5)?0:1;send(p.id,Math.round(p.target*100));redraw();render();
      }));
    });
    panel.appendChild(chip('الستارة','فتح','send',false,function(){send('SUNSHADE',100);say('الستارة: فتح')}));
    panel.appendChild(chip('الستارة','غلق','send',false,function(){send('SUNSHADE',0);say('الستارة: غلق')}));
    var inv=false;try{inv=localStorage.getItem('invWin')==='1'}catch(e){}
    panel.appendChild(chip('عكس اتجاه النوافذ',inv?'مفعّل':'غير مفعّل','',inv,function(){
      try{localStorage.setItem('invWin',inv?'0':'1')}catch(e){} render();
    }));
  }else if(tab==='light'){
    LIGHTS.forEach(function(l){
      panel.appendChild(chip(l.t,l.send?'يُرسل للسيارة':'محاكاة',l.c+(l.send?' send':''),lightOn[l.id],function(){setLight(l.id,!lightOn[l.id])}));
    });
    panel.appendChild(chip('إطفاء الكل','','',false,function(){LIGHTS.forEach(function(l){setLight(l.id,false)})}));
  }else if(tab==='door'){
    DOORS.forEach(function(d){
      panel.appendChild(chip(d.t,doorTgt[d.id]>.5?'مفتوح':'مغلق','amber',doorTgt[d.id]>.5,function(){setDoor(d.id,doorTgt[d.id]>.5?0:1)}));
    });
    panel.appendChild(chip('فتح كل الأبواب','','',false,function(){DOORS.forEach(function(d){setDoor(d.id,1)})}));
    panel.appendChild(chip('غلق كل الأبواب','','',false,function(){DOORS.forEach(function(d){setDoor(d.id,0)})}));
  }else{
    panel.appendChild(chip('فحص خصائص السيارة','قراءة فقط','',false,probe));
    panel.appendChild(chip('مزامنة الأنوار',syncOn?'تعمل':'متوقفة','',syncOn,function(){syncOn=!syncOn;render();if(syncOn)syncTick()}));
    var pre=document.createElement('pre');pre.id='out';pre.textContent=outTxt;panel.appendChild(pre);
  }
}
var outTxt='',syncOn=false;
document.querySelectorAll('#tabs button').forEach(function(b){
  b.addEventListener('click',function(){
    var same=(tab===b.dataset.tab);tab=b.dataset.tab;
    document.querySelectorAll('#tabs button').forEach(function(x){x.classList.toggle('act',x===b)});
    if(same)panel.classList.toggle('show');else panel.classList.add('show');
    render();
  });
});
render();

/* ---------------- الإرسال للسيارة ---------------- */
function send(id,pct){ if(window.Android) window.Android.onPart(id,pct); }
function cmd(name,v){ if(N){try{N.onCmd(name,v)}catch(e){say('خطأ: '+e.message)}} else say('لا يوجد اتصال بالسيارة (وضع المعاينة)'); }
function probe(){
  if(!N||!N.probe){outTxt='لا يوجد جسر أندرويد';render();return}
  try{outTxt=N.probe()}catch(e){outTxt='خطأ: '+e.message}
  render();
}
function syncTick(){
  if(!syncOn||!N||!N.readLights)return;
  try{
    var j=JSON.parse(N.readLights());
    if(j.main!=null)setLight('low',j.main>0,true);
    if(j.high!=null)setLight('high',j.high>0,true);
    if(j.hazard!=null)setLight('haz',j.hazard>0,true);
  }catch(e){}
  setTimeout(syncTick,2000);
}

/* ---------------- الجزء ثلاثي الأبعاد ---------------- */
var D=null,T=null,scene=null,gltf=null,ready=false;
var doorTracks={},doorMeshes=[],glowObjs={},emat={},blinkOn=true,blinkTimer=null,anim=false;
function redraw(){ try{D.controls.dispatchEvent({type:'change'})}catch(e){} }

function keyOfDoor(n){
  if(/^Coolray_Door_FL_/.test(n))return 'FL';
  if(/^Coolray_Door_FR_/.test(n))return 'FR';
  if(/^Coolray_Door_RL_/.test(n))return n.replace('dengdai001','dengdai').indexOf('001')>=0?'RR':'RL';
  if(/^Coolray_(Trunk_|Rear_Logo|Rear_Tail_Light001|Hydraulic_rod\w*001)/.test(n))return 'TRUNK';
  return null;
}
function splitTrack(name){var i=name.lastIndexOf('.');return [name.slice(0,i),name.slice(i+1)]}
function setupDoors(){
  var clip=(gltf.animations||[])[0];
  if(!clip){say('لا توجد حركة للأبواب في النموذج');return}
  clip.tracks.forEach(function(tr){
    var sp=splitTrack(tr.name),nn=sp[0],path=sp[1];
    var key=keyOfDoor(nn);if(!key)return;
    var obj=scene.getObjectByName(nn);if(!obj)return;
    var w=path==='quaternion'?4:3;if(path!=='quaternion'&&path!=='position')return;
    var v=tr.values,n=v.length/w,best=0,bi=0;
    for(var i=1;i<n;i++){
      var d=0;for(var k=0;k<w;k++){var x=v[i*w+k]-v[k];d+=x*x}
      if(d>best){best=d;bi=i}
    }
    if(best<1e-8)return;
    var rest=Array.prototype.slice.call(v,0,w),open=Array.prototype.slice.call(v,bi*w,bi*w+w);
    (doorTracks[key]=doorTracks[key]||[]).push({obj:obj,path:path,rest:rest,open:open});
  });
  ['FL','FR','RL','RR'].forEach(function(k){
    var re={FL:/^Coolray_Door_FL_(Body|CarPaint)$/,FR:/^Coolray_Door_FR_(Body|CarPaint)$/,RL:/^Coolray_Door_RL_(Body|CarPaint)$/,RR:/^Coolray_Door_RL_(Body|CarPaint)001$/}[k];
    scene.traverse(function(o){if(o.name&&re.test(o.name))o.traverse(function(m){if(m.isMesh&&!(m.material&&/Glass/.test(m.material.name)))doorMeshes.push({m:m,k:k})})});
  });
  scene.traverse(function(o){if(o.name&&/^Coolray_Trunk_(CarPaint|parts)$/.test(o.name))o.traverse(function(m){if(m.isMesh&&!(m.material&&/Glass/.test(m.material.name)))doorMeshes.push({m:m,k:'TRUNK'})})});
}
function applyDoor(k,a){
  (doorTracks[k]||[]).forEach(function(e){
    if(e.path==='quaternion'){
      var Q=e.obj.quaternion.constructor;
      var q0=new Q(e.rest[0],e.rest[1],e.rest[2],e.rest[3]),q1=new Q(e.open[0],e.open[1],e.open[2],e.open[3]);
      e.obj.quaternion.copy(q0);e.obj.quaternion.slerp(q1,a);
    }else{
      e.obj.position.set(e.rest[0]+(e.open[0]-e.rest[0])*a,e.rest[1]+(e.open[1]-e.rest[1])*a,e.rest[2]+(e.open[2]-e.rest[2])*a);
    }
  });
  if(doorTracks[k]&&doorTracks[k][0])doorTracks[k][0].obj.updateMatrixWorld(true);
  /* تحديث منطقة اللمس للنافذة التابعة للباب */
  var part=(D.PARTS||[]).filter(function(p){return p.id===k})[0];
  if(part&&part.glass&&part.zone){
    part.glass.updateWorldMatrix(true,false);
    part.zone.matrix.copy(part.glass.matrixWorld);part.zone.matrixWorld.copy(part.glass.matrixWorld);
    try{part.anchor=new T.Box3().setFromObject(part.zone).getCenter(new T.Vector3())}catch(e){}
  }
}
function setDoor(k,t){
  doorTgt[k]=t;
  if(k==='HOOD'){doorAmt[k]=t;say('الكاپوت: '+(t?'مفتوح (حالة فقط — غير موجود كجزء متحرك في النموذج)':'مغلق'));render();return}
  startTick();render();
  say((DOORS.filter(function(d){return d.id===k})[0]||{}).t+': '+(t?'فتح':'غلق')+' (محاكاة)');
}
var last=0,ticking=false;
function startTick(){if(!ticking){ticking=true;last=performance.now();tick()}}
function tick(){
  if(!ready){ticking=false;return}
  var now=performance.now(),dt=Math.min(.05,(now-last)/1000||.016);last=now;
  var busy=false;
  Object.keys(doorTgt).forEach(function(k){
    if(k==='HOOD')return;
    var d=doorTgt[k]-doorAmt[k];
    if(Math.abs(d)>.002){doorAmt[k]+=Math.sign(d)*Math.min(Math.abs(d),dt/.9);applyDoor(k,doorAmt[k]);busy=true}
  });
  /* مزامنة نسب النوافذ في الأزرار */
  redraw();
  if(busy)requestAnimationFrame(tick);else ticking=false;
}

/* ---------------- الأنوار (محاكاة) ---------------- */
function gradTex(kind){
  var c=document.createElement('canvas');c.width=c.height=128;var g=c.getContext('2d');
  if(kind==='disc'){
    var r=g.createRadialGradient(64,64,0,64,64,64);
    r.addColorStop(0,'rgba(255,255,255,1)');r.addColorStop(.35,'rgba(255,255,255,.55)');r.addColorStop(1,'rgba(255,255,255,0)');
    g.fillStyle=r;g.fillRect(0,0,128,128);
  }else{ /* beam: v=0 قرب السيارة → v=1 بعيداً */
    var lg=g.createLinearGradient(0,128,0,0);
    lg.addColorStop(0,'rgba(255,255,255,.95)');lg.addColorStop(.6,'rgba(255,255,255,.35)');lg.addColorStop(1,'rgba(255,255,255,0)');
    g.fillStyle=lg;g.fillRect(0,0,128,128);
    g.globalCompositeOperation='destination-in';
    var hg=g.createLinearGradient(0,0,128,0);
    hg.addColorStop(0,'rgba(0,0,0,0)');hg.addColorStop(.25,'rgba(0,0,0,1)');hg.addColorStop(.75,'rgba(0,0,0,1)');hg.addColorStop(1,'rgba(0,0,0,0)');
    g.fillStyle=hg;g.fillRect(0,0,128,128);
  }
  return c;
}
var TexCtor=null,GeoCtor=null,AttrCtor=null,texCache={};
function findCtors(){
  scene.traverse(function(o){
    if(!TexCtor&&o.isMesh&&o.material&&o.material.map)TexCtor=o.material.map.constructor;
    if(!GeoCtor&&o.isMesh&&o.geometry&&o.geometry.index){GeoCtor=o.geometry.constructor;AttrCtor=o.geometry.index.constructor}
  });
}
function tex(kind){
  if(texCache[kind])return texCache[kind];
  var t=new TexCtor(gradTex(kind));t.needsUpdate=true;texCache[kind]=t;return t;
}
function quad(w,h){
  var hw=w/2,hh=h/2,g=new GeoCtor();
  g.setAttribute('position',new AttrCtor(new Float32Array([-hw,-hh,0,hw,-hh,0,hw,hh,0,-hw,hh,0]),3));
  g.setAttribute('uv',new AttrCtor(new Float32Array([0,0,1,0,1,1,0,1]),2));
  g.setIndex(new AttrCtor(new Uint16Array([0,1,2,0,2,3]),1));
  return g;
}
function glow(group,kind,color,w,h,pos,rot,op){
  var m=new T.Basic({color:color,map:TexCtor?tex(kind):null,transparent:true,opacity:op,depthWrite:false,blending:2,side:2,fog:false});
  var o=new T.Mesh(quad(w,h),m);
  o.position.set(pos[0],pos[1],pos[2]);o.rotation.set(rot[0],rot[1],rot[2]);
  o.renderOrder=7;o.visible=false;o.userData.base=op;o.frustumCulled=false;
  scene.add(o);(glowObjs[group]=glowObjs[group]||[]).push(o);return o;
}
function setupGlows(){
  var Y=Math.PI/2,H=1.0;
  /* مواضع بحسب أبعاد النموذج: عرض ±0.9، الأمام z≈+2.1، الخلف z≈-1.95، اليسار x>0 */
  [1,-1].forEach(function(s){
    glow('pos','disc',0xfff2cc,.34,.34,[s*.62,.86,2.16],[0,0,0],.55);
    glow('low','disc',0xffffff,.42,.42,[s*.62,.86,2.17],[0,0,0],.8);
    glow('high','disc',0xdfeaff,.6,.6,[s*.62,.86,2.18],[0,0,0],.95);
    glow('drl','disc',0xffffff,.5,.16,[s*.55,.9,2.15],[0,0,0],.9);
    glow('ffog','disc',0xffd24a,.3,.3,[s*.6,.5,2.22],[0,0,0],.9);
    glow('pos','disc',0xff2a2a,.3,.3,[s*.66,1.03,-1.99],[0,Math.PI,0],.5);
    glow('brake','disc',0xff2a2a,.5,.5,[s*.62,1.03,-2.0],[0,Math.PI,0],1);
    glow('rev','disc',0xffffff,.3,.3,[s*.4,.62,-2.0],[0,Math.PI,0],.9);
    var tag=(s>0)?'tl':'tr';
    glow(tag,'disc',0xffa000,.34,.34,[s*.78,.82,2.05],[0,s*.8,0],1);
    glow(tag,'disc',0xffa000,.34,.34,[s*.74,1.03,-1.97],[0,Math.PI,0],1);
    glow(tag,'disc',0xffa000,.3,.3,[s*.9,.9,1.35],[0,Y,0],.9);
  });
  glow('rfog','disc',0xff2a2a,.36,.36,[0,.62,-2.0],[0,Math.PI,0],1);
  glow('cabin','disc',0xffe9b0,1.1,1.1,[0,1.36,-0.05],[-Y,0,0],.55);
  /* حزم الضوء على الأرض */
  glow('low','beam',0xfff4d8,2.0,4.5,[0,.02,4.45],[Y,0,0],.55);
  glow('high','beam',0xe6f0ff,2.4,9,[0,.025,6.8],[Y,0,0],.6);
  glow('ffog','beam',0xffe08a,3.0,2.6,[0,.03,3.5],[Y,0,0],.4);
  glow('rev','beam',0xffffff,1.4,2.4,[0,.02,-3.2],[-Y,0,0],.35);
}
/* خامات المصابيح الحقيقية في النموذج */
function setupMats(){
  scene.traverse(function(o){
    if(!(o.isMesh&&o.material))return;
    var ms=Array.isArray(o.material)?o.material:[o.material];
    ms.forEach(function(m){
      if(!m.name||!m.emissive||emat[m.name+'#'+m.uuid])return;
      if(/^Coolray_(Light White|Light Red|Light_Red|Symbol White)$/.test(m.name)){
        emat[m.name+'#'+m.uuid]={m:m,name:m.name,c:m.emissive.clone(),i:m.emissiveIntensity};
      }
    });
  });
}
function emissive(name,hex,inten){
  Object.keys(emat).forEach(function(k){
    var e=emat[k];if(e.name!==name)return;
    if(hex==null){e.m.emissive.copy(e.c);e.m.emissiveIntensity=e.i}
    else{e.m.emissive.set(hex);e.m.emissiveIntensity=inten}
  });
}
function applyLights(){
  var L=lightOn,bl=blinkOn;
  var show={
    pos:L.pos||L.low||L.high,
    low:L.low&&!L.high,
    high:L.high,
    drl:L.drl,
    ffog:L.ffog,
    rfog:L.rfog,
    tl:(L.tl||L.haz)&&bl,
    tr:(L.tr||L.haz)&&bl,
    brake:L.brake,
    rev:L.rev,
    cabin:L.cabin
  };
  /* أضواء "pos" الصغيرة تُظهر ما لا يخص low/high بإخفاء القرص الأكبر عند low/high */
  Object.keys(glowObjs).forEach(function(g){
    glowObjs[g].forEach(function(o){o.visible=!!show[g]});
  });
  /* المصابيح الأمامية الحقيقية */
  if(L.high||L.low||L.drl||L.pos)emissive('Coolray_Light White',0xffffff,L.high?3:(L.low?2:1.2));else emissive('Coolray_Light White',null);
  /* الخلفية */
  if(L.brake){emissive('Coolray_Light Red',0xff0000,3);emissive('Coolray_Light_Red',0xff0000,3)}
  else if(L.pos||L.low||L.high){emissive('Coolray_Light Red',0xff0000,1);emissive('Coolray_Light_Red',0xff0000,1)}
  else{emissive('Coolray_Light Red',null);emissive('Coolray_Light_Red',null)}
  /* إنارة السقف */
  if(L.cabin)emissive('Coolray_Symbol White',0xffe2a0,2.2);else emissive('Coolray_Symbol White',null);
  redraw();
}
function setLight(id,on,fromSync){
  lightOn[id]=!!on;
  if(id==='haz'&&!fromSync)cmd('hazard',on?1:0);
  var needBlink=lightOn.tl||lightOn.tr||lightOn.haz;
  if(needBlink&&!blinkTimer){blinkTimer=setInterval(function(){blinkOn=!blinkOn;applyLights()},550)}
  if(!needBlink&&blinkTimer){clearInterval(blinkTimer);blinkTimer=null;blinkOn=true}
  if(ready)applyLights();
  render();
  say((LIGHTS.filter(function(l){return l.id===id})[0]||{}).t+': '+(on?'تشغيل':'إطفاء')+(id==='haz'?' (يُرسل للسيارة)':' (محاكاة)'));
}

/* ---------------- لمس الأبواب في المجسم ---------------- */
function setupTap(){
  var cv=$('#c'),down=null,ray=new T.Raycaster(),v2=new T.Vector2();
  cv.addEventListener('pointerdown',function(e){down={x:e.clientX,y:e.clientY,t:Date.now(),zone:D.controls.enabled===false}});
  cv.addEventListener('pointerup',function(e){
    if(!down)return;var d=down;down=null;
    if(d.zone||Math.hypot(e.clientX-d.x,e.clientY-d.y)>8||Date.now()-d.t>500)return;
    var r=cv.getBoundingClientRect();
    v2.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1);
    ray.setFromCamera(v2,D.camera);
    var hits=ray.intersectObjects(doorMeshes.map(function(x){return x.m}),false);
    if(!hits.length)return;
    var m=hits[0].object,k=null;doorMeshes.forEach(function(x){if(x.m===m)k=x.k});
    if(k)setDoor(k,doorTgt[k]>.5?0:1);
  });
}

/* ---------------- بدء التشغيل ---------------- */
var bootLog=[],bootTries=0;
function stage(name,fn){
  try{fn();bootLog.push('OK  '+name)}
  catch(e){
    var st=(e&&e.stack?String(e.stack).split('\n').slice(0,3).join(' | '):'');
    bootLog.push('ERR '+name+': '+(e&&e.message)+' '+st);
    try{console.error(name+': '+(e&&e.message)+' '+st)}catch(x){}
  }
}
function boot(){
  bootTries++;
  var have={ready:!!window.__ready,gltf:!!window.__gltf,dbg:!!window.__dbg,three:!!(window.__dbg&&window.__dbg.THREE)};
  var ok=have.gltf&&have.dbg&&have.three&&(have.ready||bootTries>20);
  if(!ok){
    if(bootTries===40){outTxt='لم تكتمل التهيئة: '+JSON.stringify(have);say(outTxt);render()}
    if(bootTries<400)setTimeout(boot,300);
    return;
  }
  D=window.__dbg;T=D.THREE;gltf=window.__gltf;scene=gltf.scene;
  bootLog.push('have '+JSON.stringify(have)+' tries='+bootTries);
  stage('ctors',findCtors);
  stage('doors',setupDoors);
  stage('mats',setupMats);
  stage('glows',function(){
    var okAttr=false;try{okAttr=new AttrCtor(new Float32Array([1.5]),1).array[0]===1.5}catch(e){}
    if(!okAttr)throw new Error('BufferAttribute غير متاح');
    setupGlows();
  });
  stage('tap',setupTap);
  ready=true;
  stage('apply',applyLights);
  var tracks=0;Object.keys(doorTracks).forEach(function(k){tracks+=doorTracks[k].length});
  bootLog.push('door tracks='+tracks+' groups='+Object.keys(doorTracks).join(',')+' meshes='+doorMeshes.length+' glows='+Object.keys(glowObjs).length+' mats='+Object.keys(emat).length);
  outTxt=bootLog.join('\n');
  var bad=bootLog.filter(function(x){return x.indexOf('ERR')===0});
  say(bad.length?('تهيئة ناقصة: '+bad[0].slice(0,140)):'جاهز — الأبواب: المسها في المجسم، الأنوار والنوافذ من الألسنة أسفل');
  render();
}
setTimeout(boot,500);
var sig='';
setInterval(function(){
  if(tab!=='win'||document.hidden)return;
  var P=(window.__dbg&&window.__dbg.PARTS)||[];
  var s=P.map(function(p){return Math.round((p.amount||0)*100)}).join(',');
  if(s!==sig){sig=s;render()}
},1200);
})();
