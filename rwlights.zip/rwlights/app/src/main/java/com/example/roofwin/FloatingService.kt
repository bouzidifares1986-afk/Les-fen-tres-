package com.example.roofwin

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

class FloatingService : Service() {
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var web: WebView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var big = false
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val HOST = "app.local"

    override fun onBind(i: Intent?): IBinder? = null

    inner class Bridge {
        @JavascriptInterface fun onPart(id: String, pct: Int) {
            val area = CarControl.areaOf(id) ?: return
            io.execute {
                val r = CarControl.set(applicationContext, area, pct)
                toast(r.fold({ "$id → $pct%" }, { "خطأ $id: " + Panel.err(it) }))
            }
        }
        @JavascriptInterface fun onCmd(name: String, v: Int) {
            io.execute {
                when (name) {
                    "hazard" -> {
                        val r = CarControl.setHazard(applicationContext, v != 0)
                        toast(r.fold({ "الطوارئ: " + (if (v != 0) "تشغيل" else "إطفاء") }, { "خطأ الطوارئ: " + Panel.err(it) }))
                    }
                }
            }
        }
        @JavascriptInterface fun readLights(): String {
            val c = applicationContext
            val m = CarControl.readInt(c, CarControl.HEADLIGHT_MAIN, 0)
            val h = CarControl.readInt(c, CarControl.HEADLIGHT_HIGH, 0)
            return "{\"main\":${m ?: "null"},\"high\":${h ?: "null"}}"
        }
        /** فحص قراءة فقط: يعرض ما تُرجعه الخصائص ليُعرف ما يتاح فعلاً. */
        @JavascriptInterface fun probe(): String {
            val c = applicationContext
            val sb = StringBuilder()
            fun line(label: String, prop: Int, area: Int) {
                val r = CarControl.readRaw(c, prop, area)
                sb.append(label).append(" [0x").append(Integer.toHexString(prop)).append(" a=").append(area).append("] = ")
                    .append(r.fold({ it }, { "ERR " + Panel.err(it) })).append('\n')
            }
            line("نافذة سائق", CarControl.PROP, CarControl.DRIVER)
            line("نافذة راكب", CarControl.PROP, CarControl.FRONT_PASSENGER)
            line("نافذة خلفية ي", CarControl.PROP, CarControl.REAR_LEFT)
            line("نافذة خلفية ر", CarControl.PROP, CarControl.REAR_RIGHT)
            line("سقف", CarControl.PROP, CarControl.ROOF_GLASS)
            line("ستارة", CarControl.PROP, CarControl.SUNSHADE)
            line("كشاف رئيسي (Sunray)", CarControl.HEADLIGHT_MAIN, 0)
            line("كشاف بعيد (Sunray)", CarControl.HEADLIGHT_HIGH, 0)
            line("طوارئ (Sunray)", CarControl.HAZARD, 0)
            // خصائص AOSP القياسية — محاولة اكتشاف فقط
            line("[AOSP] غمازة TURN_SIGNAL_STATE", 0x11400408, 0)
            line("[AOSP] HEADLIGHTS_STATE", 0x11400A00, 0)
            line("[AOSP] HIGH_BEAMS_STATE", 0x11400A01, 0)
            line("[AOSP] FOG_LIGHTS_STATE", 0x11400A02, 0)
            line("[AOSP] CABIN_LIGHTS_STATE", 0x11400F01, 0)
            for ((n, a) in listOf("باب يسار أمام" to 1, "باب يمين أمام" to 4, "باب يسار خلف" to 16, "باب يمين خلف" to 64,
                "صندوق" to 0x20000000, "كاپوت" to 0x10000000))
                line("[AOSP] DOOR_POS $n", 0x16400B00, a)
            return sb.toString()
        }
    }

    private fun toast(msg: String) = main.post {
        web?.evaluateJavascript("window.__native&&window.__native(" + org.json.JSONObject.quote(msg) + ")", null)
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate() {
        super.onCreate()
        val ch = "roofwin"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "RoofWin", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch)
            .setContentTitle("RoofWin").setSmallIcon(android.R.drawable.ic_menu_manage).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density

        val title = TextView(this).apply { text = "⠿ RoofWin — اسحب للتحريك"; setTextColor(Color.WHITE); setPadding(16, 10, 16, 10) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#FF1F2937")); gravity = Gravity.CENTER_VERTICAL
            addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(Button(context).apply { text = "⤢"; setOnClickListener {
                big = !big
                lp!!.width = ((if (big) 940 else 640) * d).toInt(); lp!!.height = ((if (big) 640 else 480) * d).toInt()
                wm!!.updateViewLayout(root, lp) } })
            addView(Button(context).apply { text = "✕"; setOnClickListener { stopSelf() } })
        }

        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#10161D"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            WebView.setWebContentsDebuggingEnabled(true)
            addJavascriptInterface(Bridge(), "AndroidNative")
            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                    android.util.Log.i("RoofWinJS", m.message() + " @" + m.lineNumber()); return true
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                    if (r.url.host != HOST) return null
                    var p = (r.url.path ?: "").trimStart('/')
                    if (p.isEmpty()) p = "index.html"
                    return try {
                        val mime = when {
                            p.endsWith(".html") -> "text/html"
                            p.endsWith(".js") -> "application/javascript"
                            p.endsWith(".glb") -> "model/gltf-binary"
                            else -> "application/octet-stream"
                        }
                        WebResourceResponse(mime, "utf-8", assets.open(p))
                    } catch (e: Exception) {
                        WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                    }
                }
            }
            loadUrl("https://$HOST/index.html")
        }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        val prefs = getSharedPreferences("roofwin", MODE_PRIVATE)
        lp = WindowManager.LayoutParams((640 * d).toInt(), (480 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = prefs.getInt("x", 40); y = prefs.getInt("y", 60)
        }

        var sx = 0f; var sy = 0f; var ix = 0; var iy = 0
        title.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ix = lp!!.x; iy = lp!!.y }
                MotionEvent.ACTION_MOVE -> { lp!!.x = ix + (e.rawX - sx).toInt(); lp!!.y = iy + (e.rawY - sy).toInt(); wm!!.updateViewLayout(root, lp) }
                MotionEvent.ACTION_UP -> prefs.edit().putInt("x", lp!!.x).putInt("y", lp!!.y).apply()
            }
            true
        }
        wm!!.addView(root, lp)
    }

    override fun onDestroy() {
        root?.let { wm?.removeView(it) }
        web?.destroy(); io.shutdown()
        super.onDestroy()
    }
}
