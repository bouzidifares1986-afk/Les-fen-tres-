package com.example.roofwin

import android.content.Context

/** التحكم عبر CarPropertyManager بالـ reflection (android.car ليس في SDK العام). */
object CarControl {
    const val PROP = 0x13400BC0          // نوافذ/سقف/ستارة (من Sunray)
    const val DRIVER = 16
    const val FRONT_PASSENGER = 64
    const val REAR_LEFT = 256
    const val REAR_RIGHT = 1024
    const val ROOF_GLASS = 65536
    const val SUNSHADE = 131072

    const val HAZARD = 0x11410A01        // 289475073 — يكتبه Sunray (setIntProperty area 0)
    const val HEADLIGHT_MAIN = 0x214020A3 // 557850787 — قراءة فقط في Sunray
    const val HEADLIGHT_HIGH = 0x214020A2 // 557850786 — قراءة فقط في Sunray

    fun areaOf(id: String): Int? = when (id) {
        "FL" -> DRIVER; "FR" -> FRONT_PASSENGER; "RL" -> REAR_LEFT; "RR" -> REAR_RIGHT
        "ROOF" -> ROOF_GLASS; "SUNSHADE" -> SUNSHADE; else -> null
    }

    private var mgr: Any? = null

    private fun manager(ctx: Context): Any {
        mgr?.let { return it }
        val car = Class.forName("android.car.Car")
            .getMethod("createCar", Context::class.java).invoke(null, ctx)!!
        val m = car.javaClass.getMethod("getCarManager", String::class.java).invoke(car, "property")!!
        mgr = m; return m
    }

    fun setInt(ctx: Context, prop: Int, area: Int, value: Int): Result<Unit> = runCatching {
        val m = manager(ctx)
        m.javaClass.getMethod("setIntProperty", Int::class.java, Int::class.java, Int::class.java)
            .invoke(m, prop, area, value)
        Unit
    }

    fun set(ctx: Context, area: Int, percent: Int): Result<Unit> = setInt(ctx, PROP, area, percent.coerceIn(0, 100))

    fun setHazard(ctx: Context, on: Boolean): Result<Unit> = setInt(ctx, HAZARD, 0, if (on) 1 else 0)

    /** قراءة خام: تُرجع القيمة كنص أو رسالة الخطأ. */
    fun readRaw(ctx: Context, prop: Int, area: Int): Result<String> = runCatching {
        val m = manager(ctx)
        val v = m.javaClass.getMethod("getProperty", Int::class.java, Int::class.java).invoke(m, prop, area)
        if (v == null) "null" else v.javaClass.getMethod("getValue").invoke(v).toString()
    }

    fun readInt(ctx: Context, prop: Int, area: Int): Int? =
        readRaw(ctx, prop, area).getOrNull()?.trim('[', ']', ' ')?.toIntOrNull()

    fun get(ctx: Context, area: Int): Int? = readInt(ctx, PROP, area)
}
